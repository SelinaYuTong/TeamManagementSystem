# TeamManagerSystem
A simple app to manage a soccer or football team
