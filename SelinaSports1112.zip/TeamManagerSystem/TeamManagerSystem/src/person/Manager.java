package person;

public abstract class Manager {

	public void makeAnnouncement() {
		// TODO - implement Manager.makeAnnouncement
		throw new UnsupportedOperationException();
	}

	public void viewPlayer() {
		// TODO - implement Manager.viewPlayer
		throw new UnsupportedOperationException();
	}

}