package person;

public class LeagueManager extends Person{

	private Sponsor sponsorCollabrated;

	public LeagueManager() {
		super();  
		// TODO - implement LeagueManager.LeagueManager
		throw new UnsupportedOperationException();
	}

	public void scheduleEvent() {
		// TODO - implement LeagueManager.scheduleEvent
		throw new UnsupportedOperationException();
	}

	public void signSponsorship() {
		// TODO - implement LeagueManager.signSponsorship
		throw new UnsupportedOperationException();
	}

	public void addTeam() {
		// TODO - implement LeagueManager.addTeam
		throw new UnsupportedOperationException();
	}

	public void makeReport() {
		// TODO - implement LeagueManager.makeReport
		throw new UnsupportedOperationException();
	}

	public void getSponsorCollabrated() {
		// TODO - implement LeagueManager.getSponsorCollabrated
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param sponsorCollabrated
	 */
	public void setSponsorCollabrated(Sponsor sponsorCollabrated) {
		this.sponsorCollabrated = sponsorCollabrated;
	}

}