package person;

import utils.Event;
import utils.Team;

public class Sponsor {

	private Team teamSponsored;
	private Event eventSponsored;
	
	private Sponsor() {
		
	}

	public void offerSponsorship(Team teamSponsored) {
		
	}
	
	public void offerSponsorship(Event eventSponsored) {
		
	}

}