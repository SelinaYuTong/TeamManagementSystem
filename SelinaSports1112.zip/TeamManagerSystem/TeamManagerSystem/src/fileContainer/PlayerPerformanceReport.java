package fileContainer;

public class PlayerPerformanceReport {

	private double attendencyPercentage;

}