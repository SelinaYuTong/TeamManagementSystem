package fileContainer;

public class Announcement {

	public void publishWithinTeam() {
		// TODO - implement Announcement.publishWithinTeam
		throw new UnsupportedOperationException();
	}

	public void publishWithinLeague() {
		// TODO - implement Announcement.publishWithinLeague
		throw new UnsupportedOperationException();
	}

}