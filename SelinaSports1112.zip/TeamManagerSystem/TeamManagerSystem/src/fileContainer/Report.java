package fileContainer;

public class Report {

	public void download() {
		// TODO - implement Report.download
		throw new UnsupportedOperationException();
	}

	public void print() {
		// TODO - implement Report.print
		throw new UnsupportedOperationException();
	}

}