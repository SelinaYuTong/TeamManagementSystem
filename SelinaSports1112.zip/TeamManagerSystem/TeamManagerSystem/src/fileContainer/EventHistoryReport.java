package fileContainer;

public class EventHistoryReport {

	public void viewByResult() {
		// TODO - implement EventHistoryReport.viewByResult
		throw new UnsupportedOperationException();
	}

}