package fileContainer;

import java.util.Date;

public class FileContainer {

	private Date date;
	private String title;
	private String content;

	public void getDate() {
		// TODO - implement FileContainer.getDate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	public void getTitle() {
		// TODO - implement FileContainer.getTitle
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	public void getContent() {
		// TODO - implement FileContainer.getContent
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param content
	 */
	public void setContent(String content) {
		this.content = content;
	}

	public void publish() {
		// TODO - implement FileContainer.publish
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement FileContainer.edit
		throw new UnsupportedOperationException();
	}

	public void delete() {
		// TODO - implement FileContainer.delete
		throw new UnsupportedOperationException();
	}

	public void archive() {
		// TODO - implement FileContainer.archive
		throw new UnsupportedOperationException();
	}

	public void view() {
		// TODO - implement FileContainer.view
		throw new UnsupportedOperationException();
	}

}